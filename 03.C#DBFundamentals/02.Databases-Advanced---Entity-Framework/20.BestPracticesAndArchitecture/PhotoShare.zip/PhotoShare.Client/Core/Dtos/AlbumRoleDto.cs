﻿namespace PhotoShare.Client.Core.Dtos
{
    public class AlbumRoleDto
    {
        public int Id { get; set; }

        public string Username { get; set; }

        public string AlbumName { get; set; }
    }
}
