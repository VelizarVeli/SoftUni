﻿namespace PhotoShare.Client.Core.Dtos
{
    public class TownDto
    {
        public int Id { get; set; }

        public string TownName { get; set; }

        public string CountryName { get; set; }
    }
}
