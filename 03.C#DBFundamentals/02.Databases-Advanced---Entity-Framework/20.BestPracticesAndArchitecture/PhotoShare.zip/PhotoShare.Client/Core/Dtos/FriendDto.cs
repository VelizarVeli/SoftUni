﻿namespace PhotoShare.Client.Core.Dtos
{
    public class FriendDto
    {
        public int Id { get; set; }

        public string Username { get; set; }
    }
}