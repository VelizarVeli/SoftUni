﻿namespace _02.VillainNames
{
    public class DBConfig
    {
        public const string ConnectionString = @"Server=.;Database=MinionsDB;Integrated Security=true";
    }
}
