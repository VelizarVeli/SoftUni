﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.InitialSetup
{
    public class Connection
    {
        public const string ConnectionString = @"Server=.;Integrated Security=true";
    }
}
