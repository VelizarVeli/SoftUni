﻿namespace P01_HospitalDatabase.Data
{
   public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-8ECROG0\SQLEXPRESS;Database=FastFood;Trusted_Connection=True";
    }
}
