﻿namespace IRunesWebApp.ViewModels
{
    public class NestedViewModel
    {
        public int Count { get; set; }

        public int NestingLevel { get; set; }
    }
}
