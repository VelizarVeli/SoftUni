﻿using CosmosX.Entities.Modules.Absorbing;

namespace CosmosX.Entities.Modules.Energy
{
    public class HeatProcessor : BaseAbsorbingModule
    {
        public HeatProcessor(int id, int heatAbsorbing) : base(id, heatAbsorbing)
        {
        }
    }
}
