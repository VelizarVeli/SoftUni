﻿using TheTankGame.Core.Contracts;
using TheTankGame.Entities.Vehicles.Contracts;

namespace TheTankGame.Core
{
    public class BattleOperator : IBattleOperator
    {
        public string Battle(IVehicle attacker, IVehicle target)
        {
            throw new System.NotImplementedException();
        }
    }
}
