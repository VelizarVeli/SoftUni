﻿namespace TheTankGame.Entities.Parts
{
    using Contracts;

    public class ShellPart 
    {
       //Schedule for the next feature
    }
}