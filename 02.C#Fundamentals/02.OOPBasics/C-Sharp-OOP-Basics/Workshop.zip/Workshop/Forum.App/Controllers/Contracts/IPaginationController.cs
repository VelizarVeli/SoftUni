﻿namespace Forum.App.Controllers.Contracts
{
    interface IPaginationController
    {
        int CurrentPage { get; set; }
    }
}
