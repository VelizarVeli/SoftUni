﻿using System;

namespace _04._1.PersonClass
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
