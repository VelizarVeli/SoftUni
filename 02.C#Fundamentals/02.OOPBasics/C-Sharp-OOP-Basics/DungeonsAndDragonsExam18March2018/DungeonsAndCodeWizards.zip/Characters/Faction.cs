﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Characters
{
    public class Faction
    {
        public void retFaction(string faction)
        {
            return;
        }
    }
}
