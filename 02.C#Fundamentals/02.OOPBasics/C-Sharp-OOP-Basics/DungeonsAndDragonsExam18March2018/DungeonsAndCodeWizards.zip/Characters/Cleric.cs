﻿using DungeonsAndCodeWizards.Items;

namespace DungeonsAndCodeWizards.Characters
{
   public class Cleric:Character
    {
        public Cleric(string name, double health, double armor, double abilityPoints, Bag bag) 
            :base(name, health, armor, abilityPoints, bag)
        {
            
        }
    }
}
