﻿using System;
using System.Collections.Generic;
using System.Text;
using DungeonsAndCodeWizards.Characters;
using DungeonsAndCodeWizards.Items;

namespace DungeonsAndCodeWizards.Factories
{
    public class CharacterFactory
    {
        //public double health { get; private set; }
        //public string name { get; private set; }
        //public double armor { get; private set; }
        //public double abilityPoints { get; private set; }
        //public Bag bag { get; private set; }
        //public Faction faction { get; private set; }

        //public CharacterFactory CreateCharacter(List<string> args)
        //{
        //    var type = args[0];
        //    var id = args[1];
        //    var energyOutput = double.Parse(args[2]);

        //    switch (type)
        //    {
        //        case "Solar":
        //            return new Cleric(name, health, armor, abilityPoints, bag);
        //        case "Pressure":
        //            return new Warrior();
        //        default:
        //            throw new ArgumentException();
        //    }
        //}
    }
}
